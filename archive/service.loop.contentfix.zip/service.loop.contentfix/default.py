import re
import xbmc
import xbmcaddon
import xbmcvfs

MONITORED_ADDON_ID = 'plugin.video.the-loop'
RELATIVE_PATH = 'resources/lib/plugins/display.py'
LOG_TAG = '[service.loop.contentfix]'

# Matches setContent(int(sys.argv[1]), 'movies') or "movies", any whitespace
PATTERN = re.compile(
    r"setContent\(int\(sys\.argv\[1\]\),\s*['\"]movies['\"]\)"
)
REPLACEMENT = "setContent(int(sys.argv[1]), 'files')"


def get_target_path():
    try:
        addon = xbmcaddon.Addon(MONITORED_ADDON_ID)
    except Exception:
        xbmc.log('%s could not find addon %s (is it installed/enabled?)'
                  % (LOG_TAG, MONITORED_ADDON_ID), xbmc.LOGWARNING)
        return None
    base = addon.getAddonInfo('path')
    base = base.rstrip('/\\')
    return base + '/' + RELATIVE_PATH.replace('\\', '/')


def get_mtime(path):
    try:
        stat = xbmcvfs.Stat(path)
        return stat.st_mtime()
    except Exception:
        xbmc.log('%s could not stat file: %s' % (LOG_TAG, path), xbmc.LOGWARNING)
        return None


def patch_file(path):
    f = xbmcvfs.File(path, 'r')
    content = f.read()
    f.close()

    new_content, count = PATTERN.subn(REPLACEMENT, content)

    if count > 0:
        f = xbmcvfs.File(path, 'w')
        f.write(new_content)
        f.close()
        xbmc.log('%s patched %d occurrence(s) in display.py' % (LOG_TAG, count), xbmc.LOGINFO)
        xbmc.executebuiltin(
            'Notification(Loop Content Fix,display.py reverted to files,3000)'
        )
    else:
        xbmc.log('%s file changed but no patch needed' % LOG_TAG, xbmc.LOGDEBUG)


def check_and_patch(last_mtime):
    """Only reads/patches the file if its mtime differs from last_mtime.
    Returns the mtime to remember for next time."""
    path = get_target_path()
    if not path or not xbmcvfs.exists(path):
        xbmc.log('%s target file not found: %s' % (LOG_TAG, path), xbmc.LOGWARNING)
        return last_mtime

    current_mtime = get_mtime(path)
    if current_mtime is None:
        return last_mtime

    if current_mtime == last_mtime:
        # File untouched since last check - skip reading/patching entirely
        return last_mtime

    xbmc.log('%s detected file change (mtime %s -> %s), checking content'
              % (LOG_TAG, last_mtime, current_mtime), xbmc.LOGDEBUG)
    patch_file(path)

    # Re-stat after any write, since patching updates mtime again
    return get_mtime(path)


if __name__ == '__main__':
    # Check once at Kodi startup only (last_mtime is None so this always inspects the file)
    check_and_patch(None)
