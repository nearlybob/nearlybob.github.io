# -*- coding: utf-8 -*-
"""
Loop Guide Customization Patcher
---------------------------------
Runs once at Kodi startup. Reapplies a set of edits to
plugin.video.loopguide's files, designed to survive real Loop Guide
updates - including ones that add significant new functionality - as
long as the specific code/UI being patched still exists in some form.

Targets three files: epg_window.xml, epg_window.py, and common.py (see
resources/patches/*.json). Most patches are cosmetic (non-functional)
tweaks, but common.py and part of epg_window.py also carry the
Premium Content feature (fetching, parsing, and integrating The
Loop's own DRM-protected match feed into the Sports Guide) as a
positional patch, since that isn't part of Loop Guide's own upstream
source. common.py is wrapped in the same obfuscation as epg_window.py
and goes through the same decode/patch/re-encode path below. Premium
Content's UK/US kickoff-time conversion is done with a small
self-contained pure-Python DST calculation (see _uk_is_bst/
_us_eastern_is_dst in the patch data) rather than an external timezone
library, so there's no separate dependency to install.

Two kinds of edit are used, per file (see resources/patches/*.json):

  - "global": an (old, new) pair that is safe to replace EVERYWHERE it
    appears, unconditionally - e.g. a specific colour value that should
    always become a specific other colour, no matter which control or
    which line of code it's on. These don't depend on surrounding code
    at all, so they survive even a substantial rewrite of the
    surrounding logic (e.g. Loop Guide restructuring how its menus are
    built between versions).

  - "positional": a small edit that legitimately only makes sense in
    one specific place (e.g. the exact size/position of one specific
    label, or removing one specific block of controls). These are
    anchored to the minimum amount of exact surrounding original text
    needed to identify that one location uniquely, and are applied the
    same way as before:
      - old text found once  -> (re)apply the edit
      - old text not found, but new text already present -> already
        applied, nothing to do
      - neither found (or old text found more than once) -> that
        specific edit is skipped and logged; every other edit in the
        file is unaffected.

Global edits are applied first, then positional ones. Nothing is ever
overwritten wholesale - a real functional update only costs the
specific positional edits whose immediate surroundings actually
changed, and global edits are essentially immune to code restructuring
since they don't look at surrounding code at all.

Check kodi.log (search for "LoopGuide Patcher") after any Loop Guide
update for a full report of what applied, what was already fine, and
what needed a manual look.
"""

import base64
import json
import os
import re
import time
import zlib

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
LOOPGUIDE_PATH = xbmcvfs.translatePath('special://home/addons/plugin.video.loopguide')

LOG_PREFIX = '[LoopGuide Patcher] '

TARGETS = [
    {
        'label': 'epg_window.xml',
        'patch_file': os.path.join(ADDON_PATH, 'resources', 'patches', 'xml_hybrid.json'),
        'target': os.path.join(
            LOOPGUIDE_PATH, 'resources', 'skins', 'Default', '1080i', 'epg_window.xml'
        ),
    },
    {
        'label': 'epg_window.py',
        'patch_file': os.path.join(ADDON_PATH, 'resources', 'patches', 'py_hybrid.json'),
        'target': os.path.join(LOOPGUIDE_PATH, 'resources', 'lib', 'epg_window.py'),
    },
    {
        'label': 'common.py',
        'patch_file': os.path.join(ADDON_PATH, 'resources', 'patches', 'py_common_hybrid.json'),
        'target': os.path.join(LOOPGUIDE_PATH, 'resources', 'lib', 'common.py'),
    },
]


def log(message, level=xbmc.LOGINFO):
    xbmc.log(LOG_PREFIX + message, level)


def read_text(path):
    if not os.path.isfile(path):
        return None
    try:
        with open(path, 'rb') as f:
            return f.read().decode('utf-8')
    except Exception as exc:
        log('Failed to read {0}: {1}'.format(path, exc), xbmc.LOGERROR)
        return None


# --- Handling for Loop Guide's own reversible obfuscation wrapper -------
#
# Some Loop Guide releases wrap epg_window.py and common.py in one or
# more layers of:
#   _ = lambda __ : __import__('zlib').decompress(__import__('base64').b64decode(__[::-1]));exec((_)(b'<reversed-base64-zlib-blob>'))
# This is a reversible encoding, not a security measure. To keep
# patches working on wrapped files, each layer is unwrapped down to the
# real source, patches are applied to that, and - only if something
# actually changed - it's re-wrapped with the same number of layers.

_WRAP_RE = re.compile(r"exec\(\(_\)\(b'([^']+)'\)\)")


def _decode_layer(text):
    m = _WRAP_RE.search(text)
    if not m:
        return None
    blob = m.group(1)
    try:
        return zlib.decompress(base64.b64decode(blob[::-1])).decode('utf-8')
    except Exception:
        return None


def decode_full(text):
    """Unwrap every layer. Returns (plain_text, layer_count)."""
    layers = 0
    while True:
        nxt = _decode_layer(text)
        if nxt is None:
            return text, layers
        text = nxt
        layers += 1


def _encode_layer(source_text):
    compressed = zlib.compress(source_text.encode('utf-8'), 9)
    b64 = base64.b64encode(compressed).decode('ascii')
    header = (
        "# -----------------------------\n"
        "# Obfuscated for a reason\n"
        "# Please respect that\n"
        "# Time : {0}\n"
        "# -----------------------------\n"
    ).format(time.strftime('%a %b %d %H:%M:%S %Y'))
    body = (
        "_ = lambda __ : __import__('zlib').decompress(__import__('base64')."
        "b64decode(__[::-1]));exec((_)(b'{0}'))"
    ).format(b64[::-1])
    return header + body


def encode_full(plain_text, layers):
    text = plain_text
    for _ in range(layers):
        text = _encode_layer(text)
    return text


def load_patch_data(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as exc:
        log('Failed to load patch data {0}: {1}'.format(path, exc), xbmc.LOGERROR)
        return None


def apply_global(text, global_pairs, label):
    applied = already_ok = skipped = 0
    for idx, pair in enumerate(global_pairs):
        old, new = pair['old'], pair['new']
        count = text.count(old)

        if count:
            text = text.replace(old, new)
            applied += 1
            log('{0} [global {1}]: replaced {2} occurrence(s) of a known value'.format(
                label, idx, count
            ))
        elif text.count(new) >= 1:
            already_ok += 1
        else:
            skipped += 1
            log(
                '{0} [global {1}]: SKIPPED - value not found anywhere (removed, renamed, or '
                'the surrounding code is no longer readable, e.g. obfuscated); needs a manual '
                'look'.format(label, idx),
                xbmc.LOGWARNING,
            )
    return text, applied, already_ok, skipped


def apply_positional(text, hunks, label):
    applied = already_ok = skipped = 0
    for idx, hunk in enumerate(hunks):
        old, new = hunk['old'], hunk['new']
        summary = hunk.get('summary', '(no summary)')

        # Insert-style hunks (old is a substring of new, e.g. "insert this
        # block right before X" rather than "replace X with Y") need to be
        # judged on whether the full inserted block is already present,
        # since `old` remains findable as a substring of `new` forever
        # after a successful insert - checking old_count first would mean
        # re-inserting the block on every single run.
        #
        # Every other hunk (plain replace, or pure deletion where
        # new == "") must be judged on `old` first instead. `new` alone can
        # coincidentally already exist elsewhere in the file for a reason
        # that has nothing to do with this hunk (e.g. two unrelated hunks
        # that happen to both set the same value) - checking new before old
        # would then wrongly mark a still-needed change as already done and
        # skip it. old_count is the reliable signal for these; new is only
        # used as a fallback once old is confirmed absent.
        is_insert_style = bool(old) and old in new

        if is_insert_style and text.count(new) >= 1:
            already_ok += 1
            continue

        old_count = text.count(old)

        if old_count == 1:
            text = text.replace(old, new, 1)
            applied += 1
            log('{0} [positional {1}]: applied - {2}'.format(label, idx, summary))
        elif old_count > 1:
            skipped += 1
            log(
                '{0} [positional {1}]: SKIPPED - matched more than once, refusing to guess - {2}'.format(
                    label, idx, summary
                ),
                xbmc.LOGWARNING,
            )
        elif not new or text.count(new) >= 1:
            # old is gone: for a deletion hunk that's success on its own;
            # for a replace hunk it's only success if new is confirmed present.
            already_ok += 1
        else:
            skipped += 1
            log(
                '{0} [positional {1}]: SKIPPED - surrounding code no longer matches (likely '
                'changed by a Loop Guide update); needs a manual look - {2}'.format(
                    label, idx, summary
                ),
                xbmc.LOGWARNING,
            )
    return text, applied, already_ok, skipped


def process_target(t):
    label = t['label']
    patch_data = load_patch_data(t['patch_file'])
    if patch_data is None:
        return 0, 0, False

    raw_text = read_text(t['target'])
    if raw_text is None:
        log('{0}: target file not found, skipping ({1})'.format(label, t['target']), xbmc.LOGWARNING)
        return 0, 0, False

    # Unwrap Loop Guide's own reversible obfuscation, if present. For a
    # plain file this is a no-op: layer_count is 0 and text == raw_text.
    text, layer_count = decode_full(raw_text)
    if layer_count:
        log('{0}: {1} obfuscation layer(s) detected, decoded for patching'.format(label, layer_count))
    original = text

    global_pairs = patch_data.get('global', [])
    positional_hunks = patch_data.get('positional', [])

    text, g_applied, g_already_ok, g_skipped = apply_global(text, global_pairs, label)
    text, p_applied, p_already_ok, p_skipped = apply_positional(text, positional_hunks, label)

    total_items = len(global_pairs) + len(positional_hunks)
    success_items = g_applied + g_already_ok + p_applied + p_already_ok

    if text == original:
        log('{0}: nothing to do (already up to date)'.format(label))
        return total_items, success_items, False

    try:
        if layer_count:
            out_text = encode_full(text, layer_count)
        else:
            out_text = text
        with open(t['target'], 'wb') as f:
            f.write(out_text.encode('utf-8'))
        log(
            '{0}: updated{1} - global_applied={2}, global_already_ok={3}, global_skipped={4}, '
            'positional_applied={5}, positional_already_ok={6}, positional_skipped={7}'.format(
                label,
                ' (re-obfuscated)' if layer_count else '',
                g_applied, g_already_ok, g_skipped, p_applied, p_already_ok, p_skipped,
            )
        )
        return total_items, success_items, True
    except Exception as exc:
        log('{0}: failed to write changes: {1}'.format(label, exc), xbmc.LOGERROR)
        return total_items, success_items, False


def notify(success_items, total_items):
    try:
        import xbmcgui
        addon_name = ADDON.getAddonInfo('name')
        message = '{0} of {1} changes applied successfully'.format(success_items, total_items)
        xbmcgui.Dialog().notification(addon_name, message, xbmcgui.NOTIFICATION_INFO, 5000)
    except Exception as exc:
        log('Failed to show notification: {0}'.format(exc), xbmc.LOGERROR)


def run():
    if not os.path.isdir(LOOPGUIDE_PATH):
        log('plugin.video.loopguide is not installed - nothing to check.')
        return

    grand_total = 0
    grand_success = 0
    any_changed = False

    for t in TARGETS:
        total_items, success_items, changed = process_target(t)
        grand_total += total_items
        grand_success += success_items
        any_changed = any_changed or changed

    if any_changed:
        notify(grand_success, grand_total)


if __name__ == '__main__':
    log('Checking Loop Guide customizations...')
    run()
    log('Check complete.')
